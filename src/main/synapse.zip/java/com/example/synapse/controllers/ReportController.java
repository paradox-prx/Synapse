package com.example.synapse.controllers;

public class ReportController {
}
